Created by both Nigel Petersen and Maxim Piatine as a project. Works with PyGames.
-Maxim Piatine
