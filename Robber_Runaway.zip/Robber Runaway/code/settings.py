# Global variables representing colors
WHITE = (25, 255, 255)
BLACK = (0, 0, 0)


# Global variable used for sizing
ICON_SIZE = 24	
